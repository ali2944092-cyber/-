import React, { useState, useEffect, useRef } from 'react';
import {
  Moon,
  Sparkles,
  Heart,
  BookOpen,
  Calendar,
  Compass,
} from 'lucide-react';
import { AppSettings, CityLocation, PrayerName } from './types';
import { POPULAR_CITIES } from './data/cities';
import { calculatePrayerTimes, DayPrayerCalculations } from './utils/prayerCalculations';
import { getHijriDate, HijriDateInfo } from './utils/hijriCalendar';
import { playAdhanAudio, stopCurrentAudio } from './utils/audioPlayer';

import { Navbar } from './components/Navbar';
import { PrayerTimesSection } from './components/PrayerTimesSection';
import { QuranSection } from './components/QuranSection';
import { AdhkarSection } from './components/AdhkarSection';
import { TasbeehSection } from './components/TasbeehSection';
import { CalendarSection } from './components/CalendarSection';
import { QiblaSection } from './components/QiblaSection';
import { AdhanAlertModal } from './components/AdhanAlertModal';
import { CitySelectorModal } from './components/CitySelectorModal';
import { SettingsModal } from './components/SettingsModal';

const DEFAULT_SETTINGS: AppSettings = {
  city: POPULAR_CITIES[0], // Makkah
  calculationMethod: 'UmmAlQura',
  madhab: 'shafi',
  hijriAdjustment: 0,
  adhanMuaddhin: 'makkah',
  adhanVolume: 0.85,
  playDuaAfterAdhan: true,
  enableBrowserNotifications: false,
  prayerNotifications: {
    fajr: true,
    sunrise: false,
    dhuhr: true,
    asr: true,
    maghrib: true,
    isha: true,
  },
  quranFontSize: 24,
  reciterId: 'alafasy',
};

export default function App() {
  // Load settings from localStorage
  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem('nour_settings');
      if (saved) {
        return { ...DEFAULT_SETTINGS, ...JSON.parse(saved) };
      }
    } catch {
      // ignore
    }
    return DEFAULT_SETTINGS;
  });

  const [activeTab, setActiveTab] = useState<
    'prayer' | 'quran' | 'adhkar' | 'tasbeeh' | 'calendar' | 'qibla'
  >('prayer');

  // Modals state
  const [isCityModalOpen, setIsCityModalOpen] = useState<boolean>(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState<boolean>(false);
  const [adhanAlertData, setAdhanAlertData] = useState<{
    isOpen: boolean;
    prayerName: string;
  }>({
    isOpen: false,
    prayerName: '',
  });

  const [isDetectingLocation, setIsDetectingLocation] = useState<boolean>(false);
  const [nowDate, setNowDate] = useState<Date>(new Date());

  // Keep track of triggered prayers to prevent repeated alerts in the same minute
  const triggeredPrayersRef = useRef<Set<string>>(new Set());

  // Save settings changes
  const updateSettings = (newSettings: Partial<AppSettings>) => {
    setSettings((prev) => {
      const updated = { ...prev, ...newSettings };
      localStorage.setItem('nour_settings', JSON.stringify(updated));
      return updated;
    });
  };

  // Clock tick every second
  useEffect(() => {
    const timer = setInterval(() => {
      setNowDate(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Calculate prayer times
  const prayerCalcs: DayPrayerCalculations = calculatePrayerTimes(
    settings.city,
    settings.calculationMethod,
    settings.madhab,
    nowDate,
    settings.prayerNotifications
  );

  // Hijri Date
  const hijriDate: HijriDateInfo = getHijriDate(nowDate, settings.hijriAdjustment);

  // Check for Adhan arrival
  useEffect(() => {
    const currentTimeMs = nowDate.getTime();

    prayerCalcs.times.forEach((prayer) => {
      // Don't trigger for Sunrise
      if (prayer.id === 'sunrise') return;
      if (!settings.prayerNotifications[prayer.id]) return;

      const prayerTimeMs = prayer.time.getTime();
      const diffMs = currentTimeMs - prayerTimeMs;
      const key = `${prayer.id}-${prayer.time.toDateString()}`;

      // If within 0 to 4 seconds of prayer arrival and not yet triggered today
      if (diffMs >= 0 && diffMs < 4000 && !triggeredPrayersRef.current.has(key)) {
        triggeredPrayersRef.current.add(key);

        // Play Adhan
        playAdhanAudio(settings.adhanMuaddhin, settings.adhanVolume);

        // Show popup modal
        setAdhanAlertData({
          isOpen: true,
          prayerName: prayer.arabicName,
        });

        // Browser notification if permitted
        if (
          settings.enableBrowserNotifications &&
          'Notification' in window &&
          Notification.permission === 'granted'
        ) {
          try {
            new Notification(`حان الآن موعد أذان ${prayer.arabicName}`, {
              body: `حسب التوقيت المحلي لمدينة ${settings.city.nameArabic}`,
              icon: '/favicon.ico',
            });
          } catch {
            // ignore
          }
        }
      }
    });
  }, [nowDate, prayerCalcs.times, settings]);

  // Geolocation handler
  const handleDetectLocation = () => {
    if (!navigator.geolocation) {
      alert('خدمة تحديد الموقع الجغرافي غير مدعومة في متصفحك.');
      return;
    }

    setIsDetectingLocation(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setIsDetectingLocation(false);
        const { latitude, longitude } = pos.coords;

        // Find nearest city or create auto-detected entry
        const detectedCity: CityLocation = {
          id: 'gps-location',
          nameArabic: 'موقعي الحالي (GPS)',
          nameEnglish: 'Current Location',
          countryArabic: 'تحديد دقيق عبر الأقمار',
          countryEnglish: 'GPS Coordinates',
          latitude,
          longitude,
          timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
        };

        updateSettings({ city: detectedCity });
      },
      (err) => {
        setIsDetectingLocation(false);
        alert(`تعذر تحديد الموقع الجغرافي: ${err.message}. يمكنك اختيار مدينتك يدوياً.`);
      },
      { timeout: 10000, enableHighAccuracy: true }
    );
  };

  const handleTogglePrayerNotification = (prayerId: PrayerName) => {
    const updated = {
      ...settings.prayerNotifications,
      [prayerId]: !settings.prayerNotifications[prayerId],
    };
    updateSettings({ prayerNotifications: updated });
  };

  const handlePreviewAdhanForPrayer = (name: string) => {
    playAdhanAudio(settings.adhanMuaddhin, settings.adhanVolume);
    setAdhanAlertData({
      isOpen: true,
      prayerName: name,
    });
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-cairo selection:bg-emerald-600 selection:text-white">
      {/* Navbar with tabs and quick controls */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        city={settings.city}
        onOpenCitySelector={() => setIsCityModalOpen(true)}
        onOpenSettings={() => setIsSettingsModalOpen(true)}
        hijriDate={hijriDate}
        currentMuaddhin={settings.adhanMuaddhin}
      />

      {/* Main Content View Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {activeTab === 'prayer' && (
          <PrayerTimesSection
            calculations={prayerCalcs}
            city={settings.city}
            onSelectCity={(c) => updateSettings({ city: c })}
            onDetectLocation={handleDetectLocation}
            isDetectingLocation={isDetectingLocation}
            hijriDate={hijriDate}
            onToggleNotification={handleTogglePrayerNotification}
            onPlayAdhanPreview={handlePreviewAdhanForPrayer}
            notificationSettings={settings.prayerNotifications}
          />
        )}

        {activeTab === 'quran' && <QuranSection />}

        {activeTab === 'adhkar' && <AdhkarSection />}

        {activeTab === 'tasbeeh' && <TasbeehSection />}

        {activeTab === 'calendar' && (
          <CalendarSection
            city={settings.city}
            calculationMethod={settings.calculationMethod}
            madhab={settings.madhab}
            hijriAdjustment={settings.hijriAdjustment}
            onUpdateAdjustment={(adj) => updateSettings({ hijriAdjustment: adj })}
          />
        )}

        {activeTab === 'qibla' && <QiblaSection city={settings.city} />}
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-900 bg-slate-950/80 py-6 text-center text-xs text-slate-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 space-y-2">
          <p className="font-amiri text-base text-amber-300 font-bold">
            «اللَّهُمَّ أَعِنَّا عَلَى ذِكْرِكَ وَشُكْرِكَ وَحُسْنِ عِبَادَتِكَ»
          </p>
          <p className="text-slate-500">
            تطبيق نور الصلاة &bull; مواقيت صلاة دقيقة &bull; أذان وتنبيهات &bull; أذكار مأثورة &bull; مصحف شريف &bull; تقويم هجري وميلادي
          </p>
        </div>
      </footer>

      {/* Modals */}
      <AdhanAlertModal
        isOpen={adhanAlertData.isOpen}
        onClose={() => setAdhanAlertData({ isOpen: false, prayerName: '' })}
        prayerName={adhanAlertData.prayerName}
        cityName={settings.city.nameArabic}
        onGoToAfterPrayerAdhkar={() => {
          setActiveTab('adhkar');
          setAdhanAlertData({ isOpen: false, prayerName: '' });
        }}
      />

      <CitySelectorModal
        isOpen={isCityModalOpen}
        onClose={() => setIsCityModalOpen(false)}
        currentCity={settings.city}
        onSelectCity={(c) => updateSettings({ city: c })}
        onDetectLocation={handleDetectLocation}
        isDetecting={isDetectingLocation}
      />

      <SettingsModal
        isOpen={isSettingsModalOpen}
        onClose={() => setIsSettingsModalOpen(false)}
        settings={settings}
        onUpdateSettings={updateSettings}
      />
    </div>
  );
}
